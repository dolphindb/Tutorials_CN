from dolphindb import session as Session
from .utils import _check_category, LOAD_MODE, SequentialSession
from .utils import GROUP_FLAG, HINT_TYPE, make_MetaSQL, MetaSQL
from intervaltree import IntervalTree
from .helper import RandomSampleHelper, DataCeil, DataListCeil, get_data_func
from .helper import DataIndexHelper, DataTensorCeil
from .utils import _generate_tablename
from typing import List, Optional, Union
from queue import Queue
from math import ceil
import numpy as np
import time
import random
from threading import Thread
import copy
import time
import torch
import bisect

TRY_MAX_TIME = 5


class DataSource(object):
    prefix_sum: List[int]

    def __getitem__(self, index):
        raise NotImplementedError

    def start(self, sampler):
        raise NotImplementedError

    def join(self):
        raise NotImplementedError

    def get_next_data(self):
        raise NotImplementedError

    def __len__(self):
        return len(self.prefix_sum) - 1

    def data_len(self):
        return self.prefix_sum[-1] - self.prefix_sum[0]


class DataRealSource(DataSource):
    def __init__(
        self, sess: Session, sqls: List[MetaSQL],
        sql_mode, func_name,
        *,
        input_cols=None, target_cols=None, exclude_cols=None,
        offset=0, q_size=10, device="cpu"
    ) -> None:
        self.s = sess
        self.sqls = sqls
        self.mode = LOAD_MODE.UNKNOWN
        self.verbose = False
        self.forcePartition = True
        self.func_name = func_name
        ds_names = [self._check_sql(sql) for sql in sqls]
        self.sql_mode = sql_mode
        self.offset = offset
        self.device = device
        self.input_cols = input_cols
        self.target_cols = target_cols
        self.exclude_cols = exclude_cols
        self.q = Queue(q_size)

        all_partitions = []
        prefix_sum = [-offset]
        real_prefix_sum = [0]
        for ds, counts in ds_names:
            if self.mode == LOAD_MODE.SQLDS:
                if counts is None:
                    continue
                for i, count in enumerate(counts):
                    all_partitions.append((ds, i, count))
                    prefix_sum.append(prefix_sum[-1] + count)
                    real_prefix_sum.append(max(prefix_sum[-1], 0))
            elif self.mode == LOAD_MODE.PIVOTBY:
                assert isinstance(ds, tuple)
                all_partitions.append((ds[0], ds[1], counts))
                prefix_sum.append(prefix_sum[-1] + counts)
                real_prefix_sum.append(max(prefix_sum[-1], 0))
        self.prefix_sum = real_prefix_sum
        self.all_partitions = all_partitions

    def _check_sql(self, sql: MetaSQL):
        counts = None
        try:
            ds_name = _generate_tablename("tds_api")
            if sql.groupflag == GROUP_FLAG.PIVOTBY.value:
                self.mode = self.mode if self.mode != LOAD_MODE.UNKNOWN else LOAD_MODE.PIVOTBY
                sql_tmp = copy.deepcopy(sql)
                sql_tmp.groupflag = GROUP_FLAG.GROUPBY.value
                sql_tmp.select = sql_tmp._groupby[:-1]
                sql_tmp.groupby = sql_tmp._groupby[:-1]
                counts = self.s.run(f"exec count(*) from (eval({sql_tmp.run(self.s)}))")
                ds_name = (ds_name, f"{ds_name} = eval({sql.run(self.s)});")
                if self.verbose:
                    print(f"PIVOTBY: {ds_name} = eval({sql.run(self.s)});")
            else:
                self.mode = self.mode if self.mode != LOAD_MODE.UNKNOWN else LOAD_MODE.SQLDS
                if self.forcePartition:
                    self.s.run(f"{ds_name} = sqlDS({sql.run(self.s)}, true);")
                    if self.verbose:
                        print(f"SQLDS: {ds_name} = sqlDS({sql.run(self.s)}, true);")
                else:
                    self.s.run(f"{ds_name} = sqlDS({sql.run(self.s)}, false);")
                    if self.verbose:
                        print(f"SQLDS: {ds_name} = sqlDS({sql.run(self.s)}, false);")
                sql_count = copy.deepcopy(sql)
                sql_count.select = "< count(*) as count >"
                counts = self.s.run(f"{self.func_name}({sql_count.run(self.s)})")
        except Exception as e:
            raise RuntimeError("Error Occurred when creating sqlDS, please check your sql and other arguments.\n" + str(e))
        return ds_name, counts

    def __del__(self):
        if hasattr(self, "back_thread") and self.back_thread is not None:
            self.join()

    def start(self, sampler):
        self.sampler = sampler
        self.back_thread = Thread(target=self._prepare_data)
        self.back_thread.start()

    def join(self):
        if not hasattr(self, "back_thread") or self.back_thread is None:
            raise RuntimeError("no back_thread")
        self.back_thread.join()
        self.back_thread = None

    def _prepare_data(self):
        for index in self.sampler:
            self.q.put(self[index])

    def get_next_data(self):
        res = self.q.get()
        self.q.task_done()
        return DataTensorCeil(res)

    def _release_table(self, tbName):
        self.s.run(f"{tbName} = NULL; undef `{tbName};")

    def _get_data_with_tbName(self, temp_name):
        get_data_script = f"select {self.all_cols} from {temp_name};"
        try:
            data_array = self.s.run(get_data_script, pickleTableToList=True)
            data_array = self._convertFormat(data_array)
            data_array = np.array(data_array)
            ndim, data = self._transform_tensor_from_array(data_array)
            return True, data, ndim
        except Exception as e:
            print(f"Error Occured when executing sql: {e}")
            time.sleep(3)
            return False, None, None

    def __getitem__(self, index):
        temp_name = _generate_tablename("DataLoader")
        get_data_flag = False
        ds_name, ds_p_index, ds_p_len = self.all_partitions[index]
        for _ in range(TRY_MAX_TIME):
            if get_data_flag:
                break
            if self.mode == LOAD_MODE.SQLDS:
                load_data_scripts = f"{temp_name} = select * from {ds_name}[{ds_p_index}];"
            elif self.mode == LOAD_MODE.PIVOTBY:
                temp_name = ds_name
                load_data_scripts = ds_p_index
            self.s.run(load_data_scripts)
            self._generate_colnames(temp_name)
            get_data_flag, data, ndim = self._get_data_with_tbName(temp_name)
        if not get_data_flag:
            self._release_table(temp_name)
            raise RuntimeError('Error Occured with sql query, please check your sql and network.')
        self._release_table(temp_name)
        self.ndim = ndim
        real_len = self.prefix_sum[index+1] - self.prefix_sum[index]
        if real_len == 0:
            data = data[0:0]
        elif real_len != ds_p_len:
            data = data[-real_len:]
        return data

    def _transform_tensor_from_array(self, array):
        ndim = array.ndim
        if ndim == 2:
            array = array.T
        elif ndim == 3:
            array = np.transpose(array, (1, 0, 2))
        else:
            raise RuntimeError(f"Please check your sql, expected data ndim=2/3, but get {ndim}.")

        ans = torch.tensor(array, device=self.device)
        return ndim, ans

    def _convertFormat(self, data):
        res = []
        for item in data:
            typestr = repr(type(item.dtype))
            if typestr.find("datetime") == -1:
                res.append(item)
            else:
                res.append(item.astype(np.int64))
        return res

    def _generate_colnames(self, temp_name):
        if hasattr(self, "schema"):
            return
        schema = self.s.run(f"schema({temp_name})")["colDefs"]
        all_cols = list(schema[schema["typeInt"].apply(_check_category) == 1]["name"].values)
        if self.sql_mode == "INPUT":
            if self.input_cols is not None:
                all_cols = [x for x in all_cols if x in self.input_cols]
            elif self.exclude_cols is not None:
                all_cols = [x for x in all_cols if x not in self.exclude_cols]
        elif self.sql_mode == "TARGET":
            all_cols = [x for x in all_cols if x in self.target_cols]
        self.all_cols = ",".join(all_cols)
        self.schema = schema


class DataMockSource(DataSource):
    def __init__(self, cnts, offset=0) -> None:
        self.offset = offset
        self.cnts = cnts
        prefix_sum = [0] * (len(cnts) + 1)
        real_prefix_sum = [0] * (len(cnts) + 1)
        prefix_sum[0] = -offset
        for i in range(len(cnts)):
            prefix_sum[i+1] = prefix_sum[i] + cnts[i]
            real_prefix_sum[i+1] = max(0, prefix_sum[i+1])
        self.prefix_sum = real_prefix_sum
        self.res_data = prefix_sum
        self.q = Queue(10)

    def start(self, sampler):
        self.sampler = sampler
        self.back_thread = Thread(target=self._prepare_data)
        self.back_thread.start()

    def join(self):
        if not hasattr(self, "back_thread"):
            raise RuntimeError("no back_thread")
        self.back_thread.join()

    def _prepare_data(self):
        for index in self.sampler:
            self.q.put(self[index])

    def get_next_data(self):
        res = self.q.get()
        self.q.task_done()
        return res

    def __getitem__(self, index):
        data_start = self.res_data[index] + self.offset
        data_end = self.res_data[index+1] + self.offset
        real_len = self.prefix_sum[index+1] - self.prefix_sum[index]
        if real_len == 0:
            return DataListCeil([_ for _ in range(data_start, data_end)])[0:0]
        return DataListCeil([_ for _ in range(data_start, data_end)])[-real_len:]


class DataManager(object):
    def __init__(
        self, data_source: DataSource, sampler,
        window_size=None, window_stride=None,
    ):
        self.window_size = window_size if window_size is not None else 1
        self.window_stride = window_stride if window_stride is not None else 1

        self.data_source = data_source

        self.t = IntervalTree()
        self.q = Queue(4)

        self.prefix_sum = data_source.prefix_sum
        self.sampler = copy.deepcopy(sampler)
        self.markd = dict()
        self._cal_p_index_list()

    def start(self):
        self.back_thread = Thread(target=self._prepare_data)
        self.back_thread.start()

    def join(self):
        self.back_thread.join()

    def _prepare_data(self):
        for index in self.sampler:
            self.q.put(self[index])
        self.q.put(None)

    def _cal_p_index_list(self):
        def cal_res_list(sampler):
            res_set = set()
            for index in sampler:
                index_L = index * self.window_stride
                index_R = index_L + self.window_size - 1
                p_i, p_j = self.get_block_by_range(index_L, index_R)
                for i in range(p_i, p_j+1):
                    if i not in res_set:
                        res_set.add(i)
                        if self.prefix_sum[i+1] - self.prefix_sum[i] != 0:
                            yield i

        self.data_source.start(cal_res_list(copy.deepcopy(self.sampler)))

    def dslen(self):
        return len(self.prefix_sum) - 1

    def datalen(self):
        return self.prefix_sum[-1] - self.prefix_sum[0]

    def remove(self, index):
        L = index * self.window_stride
        R = L + self.window_size
        wsize, wstride = self.window_size, self.window_stride
        data_n = (self.datalen() - wsize) // wstride + 1
        index_L = L // wstride - (wsize - L % wstride - 1) // wstride
        index_L = max(0, index_L)
        index_R = (R) // wstride + 1
        index_R = min(index_R, data_n)

        res_L, res_R = R - wstride, L + wstride
        for tmp_index in range(index-1, index_L-1, -1):
            tmp_L = tmp_index * wstride
            res_L = tmp_L + wsize
            if tmp_index not in self.markd:
                break
        for tmp_index in range(index+1, index_R, 1):
            tmp_R = tmp_index * wstride + wsize
            res_R = tmp_R - wsize
            if tmp_index not in self.markd:
                break
        if res_L < res_R:
            self.t.chop(res_L, res_R, get_data_func(res_L, res_R))

    def _query_by_index(self, index, index_L, index_R):
        p_index_L = self.prefix_sum[index]
        p_index_R = self.prefix_sum[index+1]
        if self._check_in_memory(index_L, index_R):
            return self._query_by_index_L_R(index_L, index_R)
        else:
            data: DataCeil = self.data_source.get_next_data()
            self._merge_cache(p_index_L, p_index_R, data)
            data = self._query_by_index_L_R(index_L, index_R)
            return data

    def _merge_cache(self, index_L, index_R, data):
        res_L = sorted(self.t[:index_L])
        if len(res_L) > 0:
            if res_L[-1].end == index_L:
                data_L = res_L[-1].data
                index_L = res_L[-1].begin
                del self.t[index_L]
                data = data_L[2] + data
        res_R = sorted(self.t[index_R:])
        if len(res_R) > 0:
            if res_R[0].begin == index_R:
                data_R = res_R[0].data
                index_R = res_R[0].end
                del self.t[res_R[0].begin]
                data = data + data_R[2]
        if index_L < index_R:
            self.t[index_L:index_R] = (index_L, index_R, data)

    def _query_by_index_L_R(self, index_L, index_R):
        res = sorted(self.t[index_L:index_R])
        if len(res) == 0:
            return None
        res_L = index_L - res[0].begin
        res_R = res[0].end - index_R
        if res_L == 0 and res_R == 0:
            ans = res[0].data[2]
        elif res_L == 0:
            ans = res[0].data[2][:-res_R]
        elif res_R == 0:
            ans = res[0].data[2][res_L:]
        else:
            ans = res[0].data[2][res_L:-res_R]
        return ans

    def _check_in_memory(self, begin, end):
        res = sorted(self.t[begin:end])
        if len(res) == 0:
            return False
        elif res[0].begin <= begin and res[-1].end >= end:
            return True
        else:
            return False

    def get_block_by_range(self, index_L, index_R):
        p_i = bisect.bisect_left(self.prefix_sum, index_L+1)-1
        p_j = bisect.bisect_left(self.prefix_sum, index_R+1)-1
        return p_i, p_j

    def __getitem__(self, index):
        index_L = index * self.window_stride
        index_R = index_L + self.window_size - 1
        p_i, p_j = self.get_block_by_range(index_L, index_R)
        data = []
        if p_i == p_j:
            data = self._query_by_index(p_i, index_L, index_R+1)
            self.remove(index)
            self.markd[index] = 1
            return data.get_data()
        for i in range(p_i, p_j+1):
            if self.prefix_sum[i+1] == self.prefix_sum[i]:
                continue
            tmp_L = max(self.prefix_sum[i], index_L)
            tmp_R = min(self.prefix_sum[i+1], index_R+1)
            data.append(self._query_by_index(i, tmp_L, tmp_R))
        data = data[0].__class__.cat(data)
        self.remove(index)
        self.markd[index] = 1
        return data.get_data()

    def _get_next_index_data(self):
        while True:
            res = self.q.get()
            self.q.task_done()
            if res is not None:
                yield res
            else:
                break

    def __iter__(self):
        return self._get_next_index_data()


class DDBDataLoader(object):
    def __init__(
        self,
        ddbSession: Session,
        sql: str,
        targetCol: List[str],
        batchSize: int = 1,
        shuffle: bool = False,
        windowSize: Union[List[int], int, None] = None,
        windowStride: Union[List[int], int, None] = None,
        *,
        inputCol: Optional[List[str]] = None,
        excludeCol: Optional[List[str]] = None,
        repartitionCol: str = None,
        repartitionScheme: List[str] = None,
        groupCol: str = None,   
        groupScheme: List[str] = None,
        seed: Optional[int] = None,
        dropLast: bool = False,
        offset: int = None,
        device: str = "cpu",
        prefetchBatch: int = 1,
        prepartitionNum: int = 2,
        groupPoolSize: int = 3,
        **kwargs
    ):
        if "verbose" in kwargs:
            self.verbose = kwargs["verbose"]
        else:
            self.verbose = False

        if not isinstance(ddbSession, Session):
            raise KeyError("The type of ddbSession must be dolphindb.Session.")

        self.s: Session = SequentialSession(ddbSession)

        self.group_col = groupCol
        self.group_scheme = groupScheme
        self.repartition_col = repartitionCol
        self.repartition_scheme = repartitionScheme
        self.device = device

        self.prefetch = prefetchBatch
        self.prepartition_num = prepartitionNum
        self.grouppool_size = groupPoolSize

        sql = make_MetaSQL(ddbSession, sql)

        sqls = self._take_group_effect(groupCol, groupScheme, sql)
        self.sqls = self._take_repartition_effect(repartitionCol, repartitionScheme, sqls)

        if windowSize is None:
            self.window_size = [None, None]
        elif isinstance(windowSize, int):
            self.window_size = [windowSize, 1]
        elif isinstance(windowSize, list):
            if len(windowSize) != 2:
                raise ValueError("windowSize must be like int or [int, int].")
            self.window_size = windowSize
        else:
            raise ValueError("windowSize must be like int or [int, int].")
        if windowStride is None:
            self.window_stride = [None, None]
        elif isinstance(windowStride, int):
            self.window_stride = [windowStride, 1]
        elif isinstance(windowStride, list):
            if len(windowStride) != 2:
                raise ValueError("windowStride must be like int or [int, int].")
            self.window_stride = windowStride
        else:
            raise ValueError("windowStride must be like int or [int, int].")

        if offset is None:
            if self.window_size[0] is not None:
                offset = self.window_size[0]
            else:
                offset = 0
        self.offset = offset

        self.batch_size = batchSize
        self.shuffle = shuffle
        self.drop_last = dropLast
        self.input_colname_list = inputCol
        self.target_colname_list = targetCol
        self.exclude_colname_list = excludeCol if excludeCol is not None else []
        self.seed = seed
        self.random_ins = random.Random(seed)

        if self.batch_size <= 0:
            raise ValueError("batchSize must be greater than 0.")

        # Generate table name
        self.ds_name = _generate_tablename("tds")
        self._define_helper_func()
        self.forcePartition = True
        self.mode: LOAD_MODE = LOAD_MODE.UNKNOWN
        self.release_flag = False

        self.dms = self.sqls
        self.queue = Queue(self.prefetch)
        self.dm_queue = Queue(1)

    def _take_group_effect(self, group_col, group_scheme, sql: MetaSQL):
        if group_col is None and group_scheme is None:
            return [sql]
        if not (group_col and group_scheme):
            raise ValueError("Both groupCol and groupScheme must be specified simultaneously.")
        if not isinstance(group_col, str):
            raise TypeError("groupCol must be str.")
        if not isinstance(group_scheme, list):
            raise TypeError("groupScheme must be list.")
        res_sqls = []
        for scheme in group_scheme:
            scheme = str(scheme)
            res_sql = copy.deepcopy(sql)
            res_sql.add_where([f"< {group_col} = {scheme} >"])
            res_sqls.append(res_sql)
        return res_sqls

    def _take_repartition_effect(self, repartition_col, repartition_scheme, sqls):
        if repartition_col is None and repartition_scheme is None:
            return [[sql] for sql in sqls]
        if not (repartition_col and repartition_scheme):
            raise ValueError("Both repartitionCol and repartitionScheme must be specified simultaneously.")
        if not isinstance(repartition_col, str):
            raise TypeError("repartitionCol must be str.")
        if not isinstance(repartition_scheme, list):
            raise TypeError("repartitionScheme must be list.")
        res_sqls = [[] for _ in range(len(sqls))]
        for i, sql in enumerate(sqls):
            for scheme in repartition_scheme:
                res_sql = copy.deepcopy(sql)
                res_sql.add_where([f"< {repartition_col} = {scheme} >"])
                res_sqls[i].append(res_sql)
        return res_sqls

    def _create_data_manager(self, sqls, seed):
        input_window_size = self.window_size[0] if self.window_size[0] is not None else 1
        target_window_size = self.window_size[1] if self.window_size[1] is not None else 1
        input_window_stride = self.window_stride[0] if self.window_stride[0] is not None else 1
        target_window_stride = self.window_stride[1] if self.window_stride[1] is not None else 1

        ds_input = DataRealSource(
            self.s, sqls,
            "INPUT", self.func_name,
            input_cols=self.input_colname_list,
            target_cols=self.target_colname_list,
            exclude_cols=self.exclude_colname_list,
            offset=0, device=self.device,
            q_size=self.prepartition_num,
        )
        ds_target = DataRealSource(
            self.s, sqls,
            "TARGET", self.func_name,
            input_cols=self.input_colname_list,
            target_cols=self.target_colname_list,
            exclude_cols=self.exclude_colname_list,
            offset=self.offset, device=self.device,
            q_size=self.prepartition_num,
        )
        data_num_input = (ds_input.data_len() - input_window_size) // input_window_stride + 1
        data_num_target = (ds_target.data_len() - target_window_size) // target_window_stride + 1

        if self.shuffle and data_num_input <= data_num_target:
            p_sampler = [_ for _ in RandomSampleHelper(len(ds_input), seed=seed)]
            index_list = DataIndexHelper(
                ds_input.prefix_sum, p_sampler,
                self.window_size[0], self.window_stride[0],
                seed=seed,
            )
        elif self.shuffle:
            p_sampler = [_ for _ in RandomSampleHelper(len(ds_target), seed=seed)]
            index_list = DataIndexHelper(
                ds_target.prefix_sum, p_sampler,
                self.window_size[1], self.window_stride[1],
                seed=seed,
            )
        else:
            index_list = [_ for _ in range(min(data_num_input, data_num_target))]
        return [
            (ds_input, index_list, self.window_size[0], self.window_stride[0]),
            (ds_target, index_list, self.window_size[1], self.window_stride[1]),
        ]

    def __del__(self):
        try:
            self.release()
        except Exception:
            pass

    def release(self):
        if not self.release_flag:
            self._release_table(self.ds_name)
            self.s.run(f"undef('{self.func_name}', DEF);")
            self.release_flag = True

    def _release_table(self, tableName):
        self.s.run(f"{tableName} = NULL; undef `{tableName};")

    def __iter__(self):
        if self.seed is None:
            new_seed = self.random_ins.randint(0, 10000)
            self.random_ins.seed(new_seed)
            self.new_seed = new_seed
        else:
            self.random_ins.seed(self.seed)
        self.back_thread = Thread(target=self._prepare_next_batch)
        self.back_thread.start()
        return self._get_next_batch_data()

    def _define_helper_func(self):
        self.func_name = _generate_tablename("UTIL_HELPER")
        self.s.run("""
            def """ + f"{self.func_name}" + """(sql){
                tmp = sqlDS(sql, true);
                length = size tmp;
                if(length == 0){return NULL}
                counts = array(LONG, length);
                for(i in 0..(length-1)){
                    counts[i] = exec * from tmp[i]
                }
                return counts
            }
        """)

    def _get_next_batch_data(self):
        while True:
            ndata = self.queue.get()
            self.queue.task_done()
            if ndata is None:
                break
            x, y = ndata
            if self.window_size[0] is None:
                x = torch.squeeze(x, dim=1)
            if self.window_size[1] is None:
                y = torch.squeeze(y, dim=1)
            yield x, y
        self.back_thread.join()

    def _prepare_next_datamanager(self, dms):
        if self.seed is None:
            seed = self.new_seed
        else:
            seed = self.seed
        while len(dms) > 0:
            if self.shuffle:
                sql_samples = self.random_ins.sample(dms, k=1)
            else:
                sql_samples = [dms[0]]
            dms.remove(sql_samples[0])
            dm_pair = self._create_data_manager(sql_samples[0], seed)
            dm = self._start_datamanager(dm_pair)
            self.dm_queue.put(dm)

    def _get_next_datamanager(self, all_len):
        while all_len:
            dm = self.dm_queue.get()
            self.dm_queue.task_done()
            yield dm
            all_len -= 1

    def _start_datamanager(self, dm_pair):
        dms = []
        for dm_msg in dm_pair:
            ds, index, wsize, wstride = dm_msg
            dm = DataManager(ds, index, wsize, wstride)
            dm.start()
            dms.append(iter(dm))
        return dms

    def _prepare_next_batch(self):
        dm_pool_size = self.grouppool_size
        dms = copy.deepcopy(self.dms)
        self.dm_thread = Thread(target=self._prepare_next_datamanager, args=(dms,))
        self.dm_thread.start()
        iter = self._get_next_datamanager(len(self.dms))

        generators = [next(iter) for _ in range(min(len(self.dms), dm_pool_size))]

        data_rows = [[], []]
        all_flag = True
        while len(generators) != 0:
            ndata = []
            try:
                if self.shuffle:
                    random_generator = self.random_ins.choice(generators)
                else:
                    random_generator = generators[0]
                data_row = [next(dm) for dm in random_generator]
                for i, data in enumerate(data_row):
                    data_rows[i].append(data)
                    if len(data_rows[i]) >= self.batch_size:
                        ndata.append(torch.stack([_.data for _ in data_rows[i]]))
                        data_rows[i] = []
                if len(ndata) > 0:
                    self.queue.put(ndata)
            except StopIteration:
                generators.remove(random_generator)
                if all_flag:
                    try:
                        new_generator = next(iter)
                        generators.append(new_generator)
                    except StopIteration:
                        all_flag = False
        if len(data_rows[0]) and not self.drop_last:
            ndata = []
            for data in data_rows:
                ndata.append(torch.stack([_.data for _ in data]))
            self.queue.put(ndata)
        self.queue.put(None)
        self.dm_thread.join()

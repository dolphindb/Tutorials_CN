package outputs_test

import (
	"testing"

	. "github.com/smartystreets/goconvey/convey"

	. "github.com/dolphindb/go-plugins/internal/telegraf/outputs"
	"github.com/dolphindb/go-plugins/test"
)

func TestConfigRevise(t *testing.T) {
	Convey("TestConfigRevise", t, func() {
		cfgValue := *test.DefaultCfg
		cfg := &cfgValue

		cfg.Revise()
		So(cfg.BatchSize, ShouldEqual, DefaultBatchSize)
		So(cfg.Throttle, ShouldEqual, DefaultThrottle)
		So(cfg.GoroutineCount, ShouldEqual, DefaultGoroutineCount)
	})
}

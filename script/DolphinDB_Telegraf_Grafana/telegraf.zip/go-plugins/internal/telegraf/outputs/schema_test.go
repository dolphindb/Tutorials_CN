package outputs

//func TestNewTableSchema(t *testing.T) {
//	DoTestInPartitionTable("TestNewTableSchema", t,
//		defaultPartitionTableConfig,
//		func(cli api.DolphinDB, db *api.Database) {
//			Convey("print schema", func() {
//				s, err := NewTableSchema(defaultCfg)
//				So(err, ShouldBeNil)
//				So(s, ShouldNotBeNil)
//
//				nb, _ := json.Marshal(&s.ColumnNameList)
//				Printf("Schema.ColumnNameList is %s\n", string(nb))
//				mb, _ := json.Marshal(&s.ColumnMetaSet)
//				Printf("Schema.ColumnMetaSet is %s\n", string(mb))
//			})
//		})
//}

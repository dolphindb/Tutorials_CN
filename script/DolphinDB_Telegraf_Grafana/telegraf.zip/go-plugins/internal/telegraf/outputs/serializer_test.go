package outputs

var ()

//func TestSerialize(t *testing.T) {
//	DoTestInPartitionTable("TestSerialize", t,
//		metricPartitionTableConfig,
//		func(cli api.DolphinDB, db *api.Database) {
//			ts, err := NewTableSchema(metricCfg)
//			So(err, ShouldBeNil)
//			So(ts, ShouldNotBeNil)
//
//			s :=  NewSerializer(ts)
//
//			Convey("metric items are equal to the table columns", func() {
//				m, expectedResult := generateMetricEqualToTableColumn()
//
//				tr, err := s.Serialize(m)
//				So(err, ShouldBeNil)
//
//				So(reflect.DeepEqual(tr, expectedResult), ShouldBeTrue)
//			})
//		})
//}

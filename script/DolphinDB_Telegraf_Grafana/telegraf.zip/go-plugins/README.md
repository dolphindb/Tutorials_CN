# Go Plugins

- [Telegraf输出插件](docs/telegraf-dolphindb-output_cn.md)  

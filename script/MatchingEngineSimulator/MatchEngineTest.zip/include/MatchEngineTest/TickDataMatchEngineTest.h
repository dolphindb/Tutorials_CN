#pragma once

#include <vector>
#include <unordered_map>
#include <fstream>
#include <ctime>

#include "CoreConcept.h"
#include "Exceptions.h"
#include "ScalarImp.h"
#include "MsgDeserializer.h"

using std::string;
using std::vector;
using std::endl;

class TickDataMatchEngineTest {
public:
    TickDataMatchEngineTest(Heap *heap, ConstantSP engineConfig);
    bool testTickData(TableSP messageStream, ConstantSP stockList);
    void setStrategyInfo();

private:
    enum class UserOrderType {
        // XSHE
        XSHEOppositeBestPrice = 0,
        XSHEOwnBestPrice = 1,
        XSHEBestFivePrices = 2,
        XSHEAllPriceWithPartial = 3,
        XSHEAllPriceNoPartial = 4,

        // XSHG
        XSHGBestFivePricesWithCancel = 0,
        XSHGBestFivePricesWithLimit = 1,
        XSHGOwnBestPrice = 2,
        XSHGOppositeBestPrice = 3,
        XSHGEMPTY = 4,

        LimitPrice = 5,
        CancelOrder = 6
    };

    struct ContextDict {
        ConstantSP timestamp;
        VectorSP stockList;
    };

    Heap *heap_;
    ConstantSP engine_;

    string market_;
    int marketOrderType_;

    FunctionDefSP getObjectFunc;
    FunctionDefSP runScriptFunc;
    FunctionDefSP getOpenOrdersFunc;
    FunctionDefSP appendMsgFunc;

    TableSP dummyQuotationTable_, dummyUserOrderTable_;
    TableSP compositeOutputTable_, tradeOutputTable_, snapshotOutputTable_;

    ConstantSP getObjectByName(const string& name) {
        std::vector<ConstantSP> args = {new String(name)};
        return getObjectFunc->call(heap_, args);
    }

    ConstantSP runScript(const string & script) {
        vector<ConstantSP> args = {new String(script)};
        return runScriptFunc->call(heap_, args);
    }

    ConstantSP createMatchEngine(const string& engine_name, const string& market, bool hasSnapshotOutput);
    void saveQuatationToEngine(ConstantSP data);
    void saveOrdersToEngine(ConstantSP data);

    // strategy
    ConstantSP tradeDate_;
    vector<vector<ConstantSP>> timeIntervals_;
    ConstantSP timeToTrigger_;
    ConstantSP timeToEnd_;
    bool strategyFlag_;
    int intervalIdx_;

    string testName_;

    void handleStrategy(ContextDict& context, ConstantSP msgTable);

};

namespace MatchEngineTestFunc {
    void setDitionary(DictionarySP dict, const vector<ConstantSP>& keys, const vector<ConstantSP>& values);
    VectorSP createVectorByValue(ConstantSP val, int size);
}


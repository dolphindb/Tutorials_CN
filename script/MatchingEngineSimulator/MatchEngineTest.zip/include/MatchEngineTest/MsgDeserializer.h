#pragma once

#include "CoreConcept.h"
#include "Exceptions.h"
#include "ScalarImp.h"

class MsgDeserializer{
public:
    MsgDeserializer(TableSP& schema): indexStart_(0){
        INDEX column = schema->columns();
        for(int i = 0; i < column; i++){
            auto type = schema->getColumnType(i);
            if(type == DT_SYMBOL){
                type = DT_STRING;
            }
            cols_.emplace_back(Util::createVector(type, 0, 1024));
            dt_.push_back((int)type);
            columnNames_.emplace_back(schema->getColumnName(i));
        }
    }
    IO_ERR deserialize(DataInputStream* blob){
        IO_ERR ret = OK;
        int colIdx = 0;
        for(auto& col: cols_){
            int numElement = 0;
            int partial;
            if(dt_[colIdx] > ARRAY_TYPE_BASE){
                ConstantSP tCol = Util::createVector((DATA_TYPE)dt_[colIdx], 1, 1);
                ret = tCol->deserialize(blob, 0, 0, 1, numElement, partial);
                if (ret != OK) return ret;
                ((Vector*)(col.get()))->append(tCol);
            }
            else
                ret = col->deserialize(blob, indexStart_, 0, 1, numElement, partial);
            colIdx++;
            if(ret != OK){
                return ret;
            }
        }
        indexStart_ += 1;
        return ret;
    }

    ConstantSP deserialize_and_return_time(DataInputStream* blob, int time_idx){
        ConstantSP time;
        int colIdx = 0;
        for(auto& col: cols_){
            int numElement = 0;
            int partial;
            if(dt_[colIdx] > ARRAY_TYPE_BASE){
                ConstantSP tCol = Util::createVector((DATA_TYPE)dt_[colIdx], 1, 1);
                tCol->deserialize(blob, 0, 0, 1, numElement, partial);
                ((Vector*)(col.get()))->append(tCol);
            }
            else
                col->deserialize(blob, indexStart_, 0, 1, numElement, partial);
            if (colIdx == time_idx) {
                time = col->get(indexStart_);
            }
            colIdx++;
        }
        indexStart_ += 1;
        return time;
    }

    VectorSP deserialize_one_row(DataInputStream* blob){
        VectorSP row_ = Util::createVector(DT_ANY, dt_.size());
        for (unsigned colIdx = 0; colIdx < dt_.size(); ++colIdx){
            int numElement = 0;
            int partial;
            if(dt_[colIdx] > ARRAY_TYPE_BASE){
                ConstantSP val = Util::createVector((DATA_TYPE)dt_[colIdx], 1, 1);
                val->deserialize(blob, 0, 0, 1, numElement, partial);
                row_->set(colIdx, val);
            }
            else{
                ConstantSP val = Util::createConstant((DATA_TYPE)dt_[colIdx]);
                val->deserialize(blob, 0, 0, 1, numElement, partial);
                row_->set(colIdx, val);
            }
        }
        return row_;
    }

    ConstantSP getTable(){
        return Util::createTable(columnNames_, cols_);
    }
    
    void clear(){
        indexStart_ = 0;
        for(auto& col: cols_){
            ((Vector*)col.get())->clear();
        }
    }
    
private:
    vector<ConstantSP> cols_;
    vector<string> columnNames_;
    vector<int> dt_;
    INDEX indexStart_;
};
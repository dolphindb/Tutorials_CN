#pragma once

#include "CoreConcept.h"
#include "Exceptions.h"
#include "ScalarImp.h"

extern "C" ConstantSP runTestTickData(Heap *heap, std::vector<ConstantSP> &arguments);
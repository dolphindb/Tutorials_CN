#ifndef PLUGINVERSION_H_
#define PLUGINVERSION_H_

const char* pluginVersion = "Ddb_Plugin_Version: 2.00.9";

#endif //PLUGINVERSION_H_
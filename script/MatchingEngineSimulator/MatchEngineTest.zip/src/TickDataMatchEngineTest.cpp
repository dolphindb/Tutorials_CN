#include "TickDataMatchEngineTest.h"

using MatchEngineTestFunc::createVectorByValue;
using MatchEngineTestFunc::setDitionary;

void MatchEngineTestFunc::setDitionary(DictionarySP dict, const vector<ConstantSP>& keys, const vector<ConstantSP>& values)
{
    if (keys.size() != values.size()) {
        throw RuntimeException("the sizes of dictionary keys and values are not consistent");
    }
    for (unsigned i = 0; i < keys.size(); ++i) {
        dict->set(keys[i], values[i]);
    }
}

VectorSP MatchEngineTestFunc::createVectorByValue(ConstantSP val, int size) {
    auto vec = Util::createVector(val->getType(), size);
    for (int i = 0; i < size; ++i) {
        vec->set(i, val);
    }
    return vec;
}

TickDataMatchEngineTest::TickDataMatchEngineTest(Heap * heap, ConstantSP engineConfig)
    : heap_(heap) {
    string name = engineConfig->get(new String("engineName"))->getString();
    market_ = engineConfig->get(new String("market"))->getString();
    if (market_ == "XSHE") {
        marketOrderType_ = static_cast<int>(UserOrderType::XSHEOppositeBestPrice);
    }
    else {
        marketOrderType_ = static_cast<int>(UserOrderType::XSHGBestFivePricesWithLimit);
    }
    
    bool hasSnapshotOutput = engineConfig->get(new String("hasSnapshotOutput"))->getBool();

    testName_ = name;
    engine_ = createMatchEngine(name, market_, hasSnapshotOutput);

    getObjectFunc = heap_->currentSession()->getFunctionDef("objByName");
    runScriptFunc = heap_->currentSession()->getFunctionDef("runScript");
    getOpenOrdersFunc = heap_->currentSession()->getFunctionDef("MatchingEngineSimulator::getOpenOrders");
    appendMsgFunc = heap_->currentSession()->getFunctionDef("appendMsg");
    if (getObjectFunc.isNull() || runScriptFunc.isNull() || getOpenOrdersFunc.isNull() \
    || appendMsgFunc.isNull()) {
        throw RuntimeException("functions needed are not complete");
    }
}

ConstantSP TickDataMatchEngineTest::createMatchEngine(const string& engine_name, const string& market_name, bool hasSnapshotOutput) {
    auto createEngineFunc = heap_->currentSession()->getFunctionDef("MatchingEngineSimulator::createMatchEngine");
    auto getEngineListFunc = heap_->currentSession()->getFunctionDef("MatchingEngineSimulator::getEngineList");
    auto stopMatchEngineFunc = heap_->currentSession()->getFunctionDef("MatchingEngineSimulator::stopMatchEngine");
    auto resetMatchEngineFunc = heap_->currentSession()->getFunctionDef("MatchingEngineSimulator::resetMatchEngine");

    if (createEngineFunc.isNull() || getEngineListFunc.isNull() || stopMatchEngineFunc.isNull() || \
        resetMatchEngineFunc.isNull()) {
        throw RuntimeException("functions needed are not complete");
    }

    // 创建引擎
    DictionarySP config = Util::createDictionary(DT_STRING, nullptr, DT_DOUBLE, nullptr);
    setDitionary(config, {new String("latency"), new String("matchedRate"), new String("dataType"), new String("outputOrderBook"), new String("depth"), new String("timeDetail")}, \
            {new Double(0), new Double(1), new Int(0), new Int(hasSnapshotOutput), new Int(10), new Int(0)});
    
    auto name = new String(engine_name);
    auto exchange = new String(market_name);

    dummyQuotationTable_ = Util::createTable({"symbol", "symbolSource", "time", "sourceType", "orderType", "price", "qty", "buyNo", "sellNo", "direction", "seqNum"}, \
                            {DT_STRING, DT_STRING, DT_TIMESTAMP, DT_INT, DT_INT, DT_DOUBLE, DT_LONG, DT_LONG, DT_LONG, DT_INT, DT_LONG}, 0, 0);
    DictionarySP quotationColMap = Util::createDictionary(DT_STRING, nullptr, DT_STRING, nullptr);
    setDitionary(quotationColMap, {new String("symbol"), new String("symbolSource"), new String("time"), new String("sourceType"), new String("orderType"), new String("price"), \
                                new String("qty"), new String("buyNo"), new String("sellNo"), new String("direction"), new String("seqNum")}, \
                                {new String("symbol"), new String("symbolSource"), new String("time"), new String("sourceType"), new String("orderType"), new String("price"), \
                                new String("qty"), new String("buyNo"), new String("sellNo"), new String("direction"), new String("seqNum")});
    
    dummyUserOrderTable_ = Util::createTable({"symbol", "time", "orderType", "price", "qty", "direction", "orderID"}, \
                        {DT_STRING, DT_TIMESTAMP, DT_INT, DT_DOUBLE, DT_LONG, DT_INT, DT_LONG}, 0, 0);
    DictionarySP userOrderColMap = Util::createDictionary(DT_STRING, nullptr, DT_STRING, nullptr);
    setDitionary(userOrderColMap, {new String("symbol"), new String("time"), new String("orderType"), new String("price"), new String("qty"), new String("direction"), new String("orderID")}, \
                                {new String("symbol"), new String("time"), new String("orderType"), new String("price"), new String("qty"), new String("direction"), new String("orderID")});

    tradeOutputTable_ = Util::createTable({"orderID", "symbol", "direction", "sendingTime", "limitPrice", "volumeTotalOriginal", "tradeTime", "tradePrice", "volumeTraded", "orderStatus", "orderReceiveTime"}, \
                        {DT_LONG, DT_STRING, DT_INT, DT_TIMESTAMP, DT_DOUBLE, DT_LONG, DT_TIMESTAMP, DT_DOUBLE, DT_LONG, DT_INT, DT_NANOTIMESTAMP}, 0, 10000000);

    compositeOutputTable_ = Util::createTable({"msgType", "content"}, {DT_INT, DT_BLOB}, 0, 0);
    
    snapshotOutputTable_ = Util::createTable({"symbol", "time", "avgBidPrice", "avgOfferPrice", "totalBidQty", "totalOfferQty", "bidPrice", "bidQty", "offerPrice", "offerQty", "lastPrice", "highPrice", "lowPrice"}, \
                        {DT_STRING, DT_TIMESTAMP, DT_DOUBLE, DT_DOUBLE, DT_LONG, DT_LONG, DATA_TYPE(DT_DOUBLE + ARRAY_TYPE_BASE), DATA_TYPE(DT_LONG + ARRAY_TYPE_BASE), \
                        DATA_TYPE(DT_DOUBLE + ARRAY_TYPE_BASE), DATA_TYPE(DT_LONG + ARRAY_TYPE_BASE), DT_DOUBLE, DT_DOUBLE, DT_DOUBLE}, 0, 0);
    vector<ConstantSP> args = {name, exchange, config, dummyQuotationTable_, quotationColMap, dummyUserOrderTable_, userOrderColMap, tradeOutputTable_, compositeOutputTable_, snapshotOutputTable_};
    auto engine = createEngineFunc->call(heap_, args);

    if (engine.isNull()) {
        throw RuntimeException("create match engine failed");
    }
    return engine;
}

void TickDataMatchEngineTest::saveQuatationToEngine(ConstantSP data) {
    vector<ConstantSP> args = {engine_, data, new Int(1)};
    appendMsgFunc->call(heap_, args);
}

void TickDataMatchEngineTest::saveOrdersToEngine(ConstantSP data) {
    vector<ConstantSP> args = {engine_, data, new Int(2)};
    appendMsgFunc->call(heap_, args);
}

void TickDataMatchEngineTest::setStrategyInfo() {
    tradeDate_ = new Date(2022, 4, 14);
    timeIntervals_.push_back({new Time(10, 0, 0, 0), new Time(11, 29, 0, 0)});
    timeIntervals_.push_back({new Time(13, 0, 0, 0), new Time(14, 29, 0, 0)});

    timeToTrigger_ = timeIntervals_[0][0];
    timeToEnd_ = timeIntervals_[0][1];
    strategyFlag_ = true;
    intervalIdx_ = 0;
}

void TickDataMatchEngineTest::handleStrategy(ContextDict& context, ConstantSP msgTable) {
    // 判断策略触发时间
    ConstantSP timestampToTrigger = new Timestamp(tradeDate_->getInt() * (long long)86400000 + timeToTrigger_->getInt());
    if (!strategyFlag_ || timestampToTrigger->getLong() > context.timestamp->getLong()) {
        return;
    }
    // 获取未完成订单
    vector<ConstantSP> args = {engine_};
    TableSP openOrders = getOpenOrdersFunc->call(heap_, args);
    int openOrderSize = openOrders->size();
    
    if (openOrderSize > 0) {
        // 撤单
        ConstantSP symbols = openOrders->getColumn(2);
        ConstantSP times = createVectorByValue(context.timestamp, openOrderSize);
        ConstantSP ordertypes = createVectorByValue(new Int(static_cast<int>(UserOrderType::CancelOrder)), openOrderSize);
        ConstantSP prices = createVectorByValue(new Double(0.0), openOrderSize);
        ConstantSP qtys = openOrders->getColumn(5);
        ConstantSP directions = createVectorByValue(new Int(1), openOrderSize);
        ConstantSP orderIDs = openOrders->getColumn(0);
        vector<ConstantSP> openOrderList = {symbols, times, ordertypes, prices, qtys, directions, orderIDs};
        TableSP ordertable = Util::createTable({"SecurityID", "time", "orderType", "price", "qty", "direction", "orderID"}, openOrderList);
        saveOrdersToEngine(ordertable);
    }
    // 每只股票下市价单（卖一价）
    int stockSize = context.stockList->size();
    ConstantSP symbols = Util::createVector(DT_SYMBOL, stockSize);
    ConstantSP times = createVectorByValue(context.timestamp, stockSize);
    ConstantSP ordertypes = createVectorByValue(new Int(marketOrderType_), stockSize);
    ConstantSP prices = createVectorByValue(new Double(100.0), stockSize);
    ConstantSP qtys = createVectorByValue(new Int(2000), stockSize);
    ConstantSP directions = createVectorByValue(new Int(1), stockSize);
    ConstantSP orderIDs = createVectorByValue(new Int(1), stockSize);
    for (int i = 0; i < stockSize; ++i) {
        symbols->set(i, context.stockList->get(i));
    }
    vector<ConstantSP> limitOrderList = {symbols, times, ordertypes, prices, qtys, directions, orderIDs};
    TableSP ordertable = Util::createTable({"SecurityID", "time", "orderType", "price", "qty", "direction", "orderID"}, limitOrderList);
    saveOrdersToEngine(ordertable);

    // 更新策略触发时间
    timeToTrigger_ = new Time(timeToTrigger_->getInt() + 60 * 1000);
    if (timeToTrigger_->getInt() > timeToEnd_->getInt()) {
        if (intervalIdx_ + 1 < int(timeIntervals_.size())) {
            ++intervalIdx_;
            timeToTrigger_ = timeIntervals_[intervalIdx_][0];
            timeToEnd_ = timeIntervals_[intervalIdx_][1];
        }
        else {
            // 策略结束
            strategyFlag_ = false;
        }
    }
}

bool TickDataMatchEngineTest::testTickData(TableSP messageStream, ConstantSP stockList) {
    TableSP tickSchema = Util::createTable({"symbol", "symbolSource", "TradeTime", "sourceType", "orderType", "price", "qty", "buyNo", "sellNo", "direction", "seqNum"}, \
            {DT_SYMBOL, DT_SYMBOL, DT_TIMESTAMP, DT_INT, DT_INT, DT_DOUBLE, DT_INT, DT_INT, DT_INT, DT_INT, DT_INT}, 0, 0);
    // MsgDeserializer是对BLOB格式数据的一个解析类，tickDeserializer用于解析逐笔数据
    MsgDeserializer tickDeserializer(tickSchema);

    vector<VectorSP> messageCols;
    for (int i = 0; i < messageStream->columns(); ++i) {
        messageCols.emplace_back(messageStream->getColumn(i));
    }
    
    ContextDict context({new Timestamp(), stockList});
    setStrategyInfo();
    
    if (stockList->size() == 0) {
        strategyFlag_ = false;
    }

    ConstantSP tradetable = Util::createTable({"symbol", "symbolSource", "TradeTime", "sourceType", "orderType", "price", "qty", "buyNo", "sellNo", "direction", "seqNum"}, \
            {DT_SYMBOL, DT_SYMBOL, DT_TIMESTAMP, DT_INT, DT_INT, DT_DOUBLE, DT_INT, DT_INT, DT_INT, DT_INT, DT_INT}, 0, 0);
    ConstantSP nowTimestamp = messageCols[0]->get(0);
    ConstantSP lastTimestamp = nowTimestamp;
    for (int i = 0; i < messageStream->size(); ++i) {
        nowTimestamp = messageCols[0]->get(i);
        string data = messageCols[2]->getString(i);
        DataInputStream stream(data.c_str(), data.size());
        if (nowTimestamp->getLong() != lastTimestamp->getLong()) {
            context.timestamp = lastTimestamp;
            TableSP msgTable = tickDeserializer.getTable(); // 同一时间戳为一批行情数据
            saveQuatationToEngine(msgTable); // 发送行情数据到引擎
            handleStrategy(context, msgTable); // 执行算法策略生成用户订单并发送用户订单到引擎
            tickDeserializer.clear();
            lastTimestamp = nowTimestamp;
        }
        tickDeserializer.deserialize(&stream); // 解析该行数据并存储到该解析类内部的表中
    }
    // 输出结果
    vector<string> arg0 = {"tmp_tradeOutputTable"};
    vector<ConstantSP> arg1 = {tradeOutputTable_};
    heap_->currentSession()->run(arg0, arg1);
    runScript("share tmp_tradeOutputTable as "+ testName_ + "_tradeOutputTable");

    arg0 = {"tmp_snapshotOutputTable"};
    arg1 = {snapshotOutputTable_};
    heap_->currentSession()->run(arg0, arg1);
    runScript("share tmp_snapshotOutputTable as "+ testName_ + "_snapshotOutputTable");

    return true;
}
#include "TickDataMatchEngineTest.h"
#include "EngineTestPlugin.h"

ConstantSP runTestTickData(Heap *heap, std::vector<ConstantSP> &arguments) {
    TableSP messageStream = arguments[0];
    ConstantSP stockList = arguments[1];
    DictionarySP engineConfig = arguments[2];

    TickDataMatchEngineTest test(heap, engineConfig);
    test.testTickData(messageStream, stockList);

    return new String("done");
}
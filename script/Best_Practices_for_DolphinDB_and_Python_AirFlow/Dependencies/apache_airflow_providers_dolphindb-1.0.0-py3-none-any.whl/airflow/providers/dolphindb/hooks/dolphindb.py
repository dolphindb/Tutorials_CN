#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import dolphindb as ddb
import pydolphindb

from airflow.providers.common.sql.hooks.sql import DbApiHook
from airflow.models import Connection

class DolphinDBHook(DbApiHook):
    """Interact with DolphinDB."""

    conn_name_attr = "dolphindb_conn_id"
    default_conn_name = "dolphindb_default"
    conn_type = "dolphindb"
    hook_name = "DolphinDB"
    placeholder = "?"

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)

    def _get_conn_config_dolphindb(self, conn: Connection) -> dict:
        conn_config = {
            "username": conn.login,
            "password": conn.password,
            "host": conn.host or "localhost",
            "port" : int(conn.port) if conn.port else 8848
        }
        if conn.extra_dejson.get("enableSSL", False):
            conn_config["enableSSL"] = conn.extra_dejson["enableSSL"]
        if conn.extra_dejson.get("enableASYNC", False):
            conn_config["enableASYNC"] = conn.extra_dejson["enableASYNC"]
        if conn.extra_dejson.get("keepAliveTime", False):
            conn_config["keepAliveTime"] = conn.extra_dejson["keepAliveTime"]
        if conn.extra_dejson.get("enableChunkGranularityConfig", False):
            conn_config["enableChunkGranularityConfig"] = conn.extra_dejson["enableChunkGranularityConfig"]
        if conn.extra_dejson.get("compress", False):
            conn_config["compress"] = conn.extra_dejson["compress"]
        if conn.extra_dejson.get("enablePickle", False):
            conn_config["enablePickle"] = conn.extra_dejson["enablePickle"]
        return conn_config

    def get_conn(self) -> ddb.session:
        conn_id = getattr(self, self.conn_name_attr)
        airflow_conn = self.get_connection(conn_id)
        config = self._get_conn_config_dolphindb(airflow_conn)
        conn = pydolphindb.connect(**config)
        return conn

    def get_uri(self) -> str:
        conn_id = getattr(self, self.conn_name_attr)
        airflow_conn = self.get_connection(conn_id)
        uri = airflow_conn.get_uri()
        return uri

def get_provider_info():
    return {
        "package-name": "apache-airflow-providers-dolphindb",
        "name": "DolphinDB",
        "description": "`DolphinDB <https://www.dolphindb.com>`__\n",
        "versions": [
            "1.0.0",
        ],
        "dependencies": ["apache-airflow-providers-common-sql>=1.3.1"],
        "integrations": [
            {
                "integration-name": "DolphinDB",
                "external-doc-url": "https://www.dolphindb.com/help/index.html",
                "how-to-guide": ["/docs/apache-airflow-providers-dolphindb/operators.rst"],
                "logo": "/integration-logos/dolphindb/DolphinDB.png",
                "tags": ["software"],
            }
        ],
        "operators": [
            {"integration-name": "DolphinDB", "python-modules": ["airflow.providers.dolphindb.operators.dolphindb"]}
        ],
        "hooks": [
            {"integration-name": "DolphinDB", "python-modules": ["airflow.providers.dolphindb.hooks.dolphindb"]}
        ],
        "connection-types": [
            {
                "hook-class-name": "airflow.providers.dolphindb.hooks.dolphindb.DolphinDBHook",
                "connection-type": "dolphindb",
            }
        ],
    }

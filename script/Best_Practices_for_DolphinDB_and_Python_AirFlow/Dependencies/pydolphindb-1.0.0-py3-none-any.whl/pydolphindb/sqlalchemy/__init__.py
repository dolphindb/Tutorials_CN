from .dialect import DolphinDBDialect

__all__ = [
    DolphinDBDialect,
]
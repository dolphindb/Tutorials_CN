import numpy as np
import pandas as pd
import os
import multiprocessing
import time
import warnings
from tqdm import tqdm

warnings.filterwarnings("ignore")
pd.options.display.width = 1200
pd.options.display.max_colwidth = 100
pd.options.display.max_columns = 10
pd.options.mode.chained_assignment = None


def level10_Diff(df, lag=20):
    """
    十档委买增额
    :param df:
    :param lag:
    :return:
    """
    temp = df[["SecurityID", "TradeTime"]]

    for i in range(10):
        temp[f"bid{i+1}"] = df[f"BidPrice{i+1}"].fillna(0)
        temp[f"bidAmt{i+1}"] = df[f"BidOrderQty{i+1}"].fillna(0) * df[
            f"BidPrice{i+1}"
        ].fillna(0)
        temp[f"prevbid{i+1}"] = temp[f"bid{i+1}"].shift(1).fillna(0)
        temp[f"prevbidAmt{i+1}"] = temp[f"bidAmt{i+1}"].shift(1).fillna(0)

    temp["bidMin"] = temp[[f"bid{i+1}" for i in range(10)]].min(axis=1)
    temp["bidMax"] = temp[[f"bid{i+1}" for i in range(10)]].max(axis=1)
    temp["prevbidMin"] = temp[[f"prevbid{i+1}" for i in range(10)]].min(axis=1)
    temp["prevbidMax"] = temp[[f"prevbid{i+1}" for i in range(10)]].max(axis=1)
    temp["pmin"] = temp[["bidMin", "prevbidMin"]].max(axis=1)
    temp["pmax"] = temp[["bidMax", "prevbidMax"]].max(axis=1)

    temp["amtDiff"] = 0.0
    for i in range(10):
        temp["amtDiff"] += temp[f"bidAmt{i+1}"] * (
            (temp[f"bid{i+1}"] >= temp["pmin"]) & (temp[f"bid{i+1}"] <= temp["pmax"])
        ).astype(int) - temp[f"prevbidAmt{i+1}"] * (
            (temp[f"prevbid{i+1}"] >= temp["pmin"])
            & (temp[f"prevbid{i+1}"] <= temp["pmax"])
        ).astype(
            int
        )
    temp["amtDiff"] = temp.groupby("SecurityID")["amtDiff"].apply(
        lambda x: x.rolling(lag, 1).sum()
    )
    return temp[["SecurityID", "TradeTime", "amtDiff"]].fillna(0)


def process_task(npz_file_path):
    npz_obj = np.load(npz_file_path, allow_pickle=True)

    df_list = []

    for file_name in npz_obj.files:
        array = npz_obj[file_name]
        df = pd.DataFrame(array, columns=column_names)
        df = level10_Diff(df, lag=20)
        df_list.append(df)

    df_total = pd.concat(df_list, axis=0)

    return df_total


if __name__ == "__main__":
    column_names = ['SecurityID', 'TradeTime', 'PreClosePx', 'OpenPx', 'HighPx', 'LowPx',
       'LastPx', 'TotalVolumeTrade', 'TotalValueTrade', 'InstrumentStatus',
       'NumTrades', 'IOPV', 'TotalBidQty', 'TotalOfferQty', 'WeightedAvgBidPx',
       'WeightedAvgOfferPx', 'TotalBidNumber', 'TotalOfferNumber',
       'BidTradeMaxDuration', 'OfferTradeMaxDuration', 'NumBidOrders',
       'NumOfferOrders', 'WithdrawBuyNumber', 'WithdrawBuyAmount',
       'WithdrawBuyMoney', 'WithdrawSellNumber', 'WithdrawSellAmount',
       'WithdrawSellMoney', 'ETFBuyNumber', 'ETFBuyAmount', 'ETFBuyMoney',
       'ETFSellNumber', 'ETFSellAmount', 'ETFSellMoney', 'BidPrice1',
       'BidPrice2', 'BidPrice3', 'BidPrice4', 'BidPrice5', 'BidPrice6',
       'BidPrice7', 'BidPrice8', 'BidPrice9', 'BidPrice10', 'BidOrderQty1',
       'BidOrderQty2', 'BidOrderQty3', 'BidOrderQty4', 'BidOrderQty5',
       'BidOrderQty6', 'BidOrderQty7', 'BidOrderQty8', 'BidOrderQty9', 'BidOrderQty10',
       'BidNumOrder1', 'BidNumOrder2', 'BidNumOrder3', 'BidNumOrder4',
       'BidNumOrder5', 'BidNumOrder6', 'BidNumOrder7', 'BidNumOrder8',
       'BidNumOrder9', 'BidNumOrder10', 'BidOrder1', 'BidOrder2', 'BidOrder3',
       'BidOrder4', 'BidOrder5', 'BidOrder6', 'BidOrder7', 'BidOrder8',
       'BidOrder9', 'BidOrder10', 'OfferPrice1', 'OfferPrice2', 'OfferPrice3',
       'OfferPrice4', 'OfferPrice5', 'OfferPrice6', 'OfferPrice7',
       'OfferPrice8', 'OfferPrice9', 'OfferPrice10', 'OfferOrderQty1',
       'OfferOrderQty2', 'OfferOrderQty3', 'OfferOrderQty4', 'OfferOrderQty5',
       'OfferOrderQty6', 'OfferOrderQty7', 'OfferOrderQty8', 'OfferOrderQty9',
       'OfferOrderQty10', 'OfferNumOrder1', 'OfferNumOrder2', 'OfferNumOrder3',
       'OfferNumOrder4', 'OfferNumOrder5', 'OfferNumOrder6', 'OfferNumOrder7',
       'OfferNumOrder8', 'OfferNumOrder9', 'OfferNumOrder10', 'OfferOrder1',
       'OfferOrder2', 'OfferOrder3', 'OfferOrder4', 'OfferOrder5',
       'OfferOrder6', 'OfferOrder7', 'OfferOrder8', 'OfferOrder9',
       'OfferOrder10']
    start_time = time.time()
    n_use = 16
    npz_dir = "/home/wjchen/workfile/python_plus_file_VS_dolphindb_on_factor_calc/npzFile"  # 将此路径替换为你的npz文件目录

    # 获取npz目录下的所有npz文件
    npz_files = [
        os.path.join(npz_dir, f) for f in os.listdir(npz_dir) if f.endswith(".npz")
    ]

    print("#" * 50 + "Multiprocessing Start" + "#" * 50)

    with multiprocessing.Pool(min(n_use, multiprocessing.cpu_count())) as pool:
        # 使用map方法分发任务，每个任务是一个npz文件的路径
        results = pool.map(process_task, npz_files)

    end_time = time.time()  # 记录结束时间

    # 将所有结果合并成一个大的DataFrame
    final_result = pd.concat(results, axis=0)

    print(f"Total execution time: {end_time - start_time} seconds")  # 打印出总的执行时间

    print(final_result)

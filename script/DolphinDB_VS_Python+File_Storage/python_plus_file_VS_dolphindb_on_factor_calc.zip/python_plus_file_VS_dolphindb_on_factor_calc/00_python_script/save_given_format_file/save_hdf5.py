import pandas as pd
import os
from tqdm import tqdm
from transform_ArrayVector_into_MultiColumn import split_array_vector_into_multicolumns

csv_path = "/home/wjchen/workfile/python_plus_file_VS_dolphindb_on_factor_calc/csvFile/"
hdf5_path = "/home/wjchen/workfile/python_plus_file_VS_dolphindb_on_factor_calc/hdf5File/"

for file_name in tqdm(os.listdir(csv_path)):
    if file_name.endswith(".csv"):
        csv_file = os.path.join(csv_path, file_name)
        df = split_array_vector_into_multicolumns(pd.read_csv(csv_file))
        hdf5_file = os.path.join(hdf5_path, file_name.replace(".csv", ".h5"))
        df.to_hdf(hdf5_file, key='data', mode='w')

from tqdm import tqdm
import dolphindb as ddb
import pandas as pd
import os
from transform_ArrayVector_into_MultiColumn import split_array_vector_into_multicolumns

# 请修改为您实际存放csv文件和期望存放pickle文件的目录
csv_path = "/home/wjchen/workfile/demo/python_plus_file_VS_dolphindb_on_factor_calc/csvFile"
pickle_path = "/home/wjchen/workfile/demo/python_plus_file_VS_dolphindb_on_factor_calc/pickleFile"

for file_name in tqdm(os.listdir(csv_path)):
    if file_name.endswith(".csv"):
        csv_file = os.path.join(csv_path, file_name)
        df = split_array_vector_into_multicolumns(pd.read_csv(csv_file))
        pickle_file = os.path.join(pickle_path, file_name.replace(".csv", ".pkl"))
        df.to_pickle(pickle_file)

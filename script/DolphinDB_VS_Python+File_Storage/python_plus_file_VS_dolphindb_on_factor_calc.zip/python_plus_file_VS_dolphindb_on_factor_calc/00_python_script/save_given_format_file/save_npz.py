import os
import pandas as pd
import numpy as np
from tqdm import tqdm
from transform_ArrayVector_into_MultiColumn import split_array_vector_into_multicolumns

csv_path = "/home/wjchen/workfile/python_plus_file_VS_dolphindb_on_factor_calc/csvFile/"
npz_dir = "/home/wjchen/workfile/python_plus_file_VS_dolphindb_on_factor_calc/npzFile/"  # Npz 文件保存目录

# 获取所有的 CSV 文件名称
csv_files = [f for f in os.listdir(csv_path) if f.endswith('.csv')]

# 计算每个 npz 文件应该包含的 csv 文件数量
num_files_per_npz = len(csv_files) // 16  # 每个npz包含的csv文件数量

# 创建一个空字典，用于最后存储所有的 NumPy 数组
data_dict = {}

for i in range(16):  # We have 16 npz files
    # 选择这一组的 csv 文件
    if i < 15:  # 对于前15个npz文件
        subset_files = csv_files[i * num_files_per_npz : (i + 1) * num_files_per_npz]
    else:  # 对于第16个npz文件
        subset_files = csv_files[i * num_files_per_npz :]  # 包含所有剩余的csv文件

    for file_name in tqdm(subset_files):
        csv_file = os.path.join(csv_path, file_name)
        df = split_array_vector_into_multicolumns(pd.read_csv(csv_file))

        # 将 DataFrame 转换为 NumPy 数组，并将数组保存到字典中
        # 使用文件名（不包括扩展名）作为数组的键
        npy_key = f"npy_{i+1}_{file_name[:-4]}"
        data_dict[npy_key] = df.to_numpy()

    # 将所有的 NumPy 数组保存到一个 npz 文件中
    npz_file = os.path.join(npz_dir, f"npz_{i+1}.npz")
    np.savez(npz_file, **data_dict)

    # 清空字典，为下一组文件做准备
    data_dict = {}

def split_array_vector_into_multicolumns(df):
    # array vector can be split into multiple columns by ,
    # for example, turn BidPrice into BidPrice1, BidPrice2, BidPrice3, BidPrice4, BidPrice5..., BidPrice10
    # BidPrice DOUBLE[],
    # BidOrderQty INT[],
    # BidNumOrder INT[],
    # BidOrder INT[],
    # OfferPrice DOUBLE[],
    # OfferOrderQty INT[],
    # OfferNumOrder INT[],
    # OfferOrder INT[],
    df['BidPrice'] = df['BidPrice'].str.split(',')
    for i in range(10):
        df[f'BidPrice{i + 1}'] = df['BidPrice'].str[i].astype(float)
    df['BidOrderQty'] = df['BidOrderQty'].str.split(',')
    for i in range(10):
        df[f'BidOrderQty{i + 1}'] = df['BidOrderQty'].str[i].astype(int)
    df['BidNumOrder'] = df['BidNumOrder'].str.split(',')
    for i in range(10):
        df[f'BidNumOrder{i + 1}'] = df['BidNumOrder'].str[i].astype(int)
    df['BidOrder'] = df['BidOrder'].str.split(',')
    for i in range(10):
        df[f'BidOrder{i + 1}'] = df['BidOrder'].str[i].astype(int)
    df['OfferPrice'] = df['OfferPrice'].str.split(',')
    for i in range(10):
        df[f'OfferPrice{i + 1}'] = df['OfferPrice'].str[i].astype(float)
    df['OfferOrderQty'] = df['OfferOrderQty'].str.split(',')
    for i in range(10):
        df[f'OfferOrderQty{i + 1}'] = df['OfferOrderQty'].str[i].astype(int)
    df['OfferNumOrder'] = df['OfferNumOrder'].str.split(',')
    for i in range(10):
        df[f'OfferNumOrder{i + 1}'] = df['OfferNumOrder'].str[i].astype(int)
    df['OfferOrder'] = df['OfferOrder'].str.split(',')
    for i in range(10):
        df[f'OfferOrder{i + 1}'] = df['OfferOrder'].str[i].astype(int)
    # Drop the original columns
    df.drop(['BidPrice', 'BidOrderQty', 'BidNumOrder', 'BidOrder', 'OfferPrice', 'OfferOrderQty', 'OfferNumOrder', 'OfferOrder'], axis=1, inplace=True)
    return df
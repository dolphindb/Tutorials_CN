#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
import itertools
from functools import reduce
import os
import multiprocessing
import time
import warnings
from tqdm import tqdm
import datetime

warnings.filterwarnings("ignore")
pd.options.display.width = 1200
pd.options.display.max_colwidth = 100
pd.options.display.max_columns = 10
pd.options.mode.chained_assignment = None



def level10_InferPriceTrend(df, lag1=60, lag2=20):
    '''
    十档买卖委托均价线性回归斜率
    :param df:
    :param lag1:
    :param lag2:
    :return:
    '''
    temp = df[["SecurityID", "DateTime"]]
    temp["amount"] = 0.
    temp["qty"] = 0.
    for i in range(10):
        temp[f"bidAmt{i+1}"] = df[f"BidPrice{i+1}"].fillna(0.) * df[f"BidOrderQty{i+1}"].fillna(0.)
        temp[f"askAmt{i+1}"] = df[f"OfferPrice{i+1}"].fillna(0.) * df[f"OfferOrderQty{i+1}"].fillna(0.)
        temp["amount"] += temp[f"bidAmt{i+1}"] + temp[f"askAmt{i+1}"]
        temp["qty"] += df[f"BidOrderQty{i+1}"].fillna(0.) + df[f"OfferOrderQty{i+1}"].fillna(0.)
    temp["inferprice"] = temp["amount"] / temp["qty"]
    temp.loc[(temp.bidAmt1 <= 0) | (temp.askAmt1 <= 0), "inferprice"] = np.nan
    temp["inferprice"] = temp["inferprice"].fillna(method='ffill').fillna(0.)

    def f(x):
        n = len(x)
        x = np.array(x)
        y = np.array([i for i in range(1, n+1)])
        return (n*sum(x*y) - sum(x)*sum(y)) / (n*sum(y*y) - sum(y)*sum(y))

    temp["inferprice"] = temp.groupby("SecurityID")["inferprice"].apply(lambda x: x.rolling(lag1 - 1, 1).apply(f))
    temp["inferprice"] = temp["inferprice"].fillna(0)
    temp["inferprice"] = temp.groupby("SecurityID")["inferprice"].apply(lambda x: x.rolling(lag2, 1).mean())
    return temp[["SecurityID", "DateTime", "inferprice"]].fillna(0)

def pool_func(tick_obj, snapshot_path_obj):
    single_tick_res = []
    # tmp_date = trade_path_obj.split('/')[-1]
    # print(tmp_date)
    # tmp_date = tmp_date[0:4] + "-" + tmp_date[4:6] + "-" + tmp_date[6:8]
    # print(tmp_date)
    for tick in tqdm(tick_obj):
        try:
            df = pd.read_parquet(os.path.join(snapshot_path_obj, tick))
            single_tick_res.append(level10_InferPriceTrend(df, lag1=60, lag2=20))
            # print(Indicator)
            # print("开盘后大单净买入占比:", Indicator)

        except Exception as error:
            single_tick_res = pd.DataFrame(columns=["SecurityID", "DateTime", "Inferprice"])
            continue

    return pd.concat(single_tick_res, axis=0)


class multi_task_split:

    def __init__(self, data, processes_to_use):
        self.data = data
        self.processes_to_use = processes_to_use

    def num_of_jobs(self):
        return min(len(self.data), self.processes_to_use, multiprocessing.cpu_count())

    def split_args(self):
        q, r = divmod(len(self.data), self.num_of_jobs())
        return (self.data[i * q + min(i, r): (i + 1) * q + min(i + 1, r)] for i in range(self.num_of_jobs()))


if __name__ == '__main__':
    n_use = 16
    # 路径修改为存放数据路径
    snapshot_path = "/hdd/hdd9/data/tiangeng/ParquetNew"
    stock_pool = os.listdir(snapshot_path)
    processes_decided = multi_task_split(stock_pool, n_use).num_of_jobs()
    print(processes_decided)
    split_args_to_process = list(multi_task_split(stock_pool, n_use).split_args())
    args = [(split_args_to_process[i], snapshot_path) for i in range(len(split_args_to_process))]
    print("#" * 50 + "Multiprocessing Start" + "#" * 50)
    t0 = time.time()
    with multiprocessing.Pool(processes=processes_decided) as pool:
        res = tqdm(pool.starmap(pool_func, args))
        print("cal time: ", time.time() - t0, "s")
        res_combined = pd.concat(res, axis=0)
        pool.close()
        print("cal time: ", time.time() - t0, "s")
    print(res_combined)


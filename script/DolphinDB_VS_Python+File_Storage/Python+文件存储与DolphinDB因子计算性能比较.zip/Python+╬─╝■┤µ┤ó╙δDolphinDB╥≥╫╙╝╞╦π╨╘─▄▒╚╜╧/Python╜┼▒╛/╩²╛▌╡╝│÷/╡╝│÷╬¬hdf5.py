#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import os

csv_path = "/hdd/hdd9/data/tiangeng/csvNew/"
hdf5_path ="/hdd/hdd9/data/tiangeng/Hdf5New/"

for file_name in os.listdir(csv_path):
    if file_name.endswith(".csv"):
        csv_file = os.path.join(csv_path, file_name)
        df = pd.read_csv(csv_file)
        hdf5_file = os.path.join(hdf5_path, file_name.replace(".csv", ".h5"))
        df.to_hdf(hdf5_file, key='data', mode='w')


# In[ ]:





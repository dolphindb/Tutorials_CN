#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import os

csv_path = "/hdd/hdd9/data/tiangeng/csvNew/"
parquet_path ="/hdd/hdd9/data/tiangeng/ParquetNew/"

for file_name in os.listdir(csv_path):
    if file_name.endswith(".csv"):
        csv_file = os.path.join(csv_path, file_name)
        df = pd.read_csv(csv_file)
        parquet_file = os.path.join(parquet_path, file_name.replace(".csv", ".parquet"))
        table = pa.Table.from_pandas(df)
        pq.write_table(table, parquet_file)


# In[ ]:





# In[ ]:





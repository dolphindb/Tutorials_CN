#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pyarrow as pa
import pandas as pd
import os

csv_path = "/hdd/hdd9/data/tiangeng/csvNew/"
feather_path ="/hdd/hdd9/data/tiangeng/FeatherNew/"

for file_name in os.listdir(csv_path):
    if file_name.endswith(".csv"):
        csv_file = os.path.join(csv_path, file_name)
        df = pd.read_csv(csv_file)
        feather_file = os.path.join(feather_path, file_name.replace(".csv", ".feather"))
        df.to_feather(feather_file)


# In[ ]:





#!/usr/bin/env python
# coding: utf-8

# In[1]:


import dolphindb as ddb
import pandas as pd
import os

csv_path = "/hdd/hdd9/data/tiangeng/csvNew/"
parquet_path ="/hdd/hdd9/data/tiangeng/PickleNew/"

for file_name in os.listdir(csv_path):
    if file_name.endswith(".csv"):
        csv_file = os.path.join(csv_path, file_name)
        df = pd.read_csv(csv_file)
        pickle_file = os.path.join(pickle_path, file_name.replace(".csv", ".pkl"))
        df.to_pickle(pickle_file)


# In[ ]:




